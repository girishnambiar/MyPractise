package steps;

import cucumber.api.java.en.Given;
import io.restassured.response.Response;
import cucumber.api.java.en.Then;
import BDDModels.RequestExtension;
import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.CoreMatchers.hasItem;

public class APITest 
{

	private static String strBaseURL = "http:////localhost:3000//";
	private static Response response;


	@Given("^I perform GET operation for \"([^\"]*)\"$")
	public void given(String param) throws Throwable 
	{
		response = RequestExtension.getOPS(param);
		System.out.println("@Given");
	}

	@Then("^I should see the author name as \"([^\"]*)\"$")
	public void then(String param) throws Throwable 
	{
		assertThat(response.getBody().jsonPath().get("author"), hasItem(param));
		System.out.println("@Then");
	}

}
