package steps;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import io.restassured.response.Response;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import BDDModels.RequestExtension;
import static org.hamcrest.MatcherAssert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.*;

public class LocalJSONPost 
{

	private static String strBaseURL = "http:////localhost:3000//";
	private static Response response;


	@Given("^I perform POST operation for \"([^\"]*)\"$")
	public void given(String param) throws Throwable 
	{
		response = RequestExtension.getOPS(param);
		System.out.println("@Given");
	}
	
	@When("^I post below values for \"([^\"]*)\"$")
	public void when(String url, DataTable objDtPosts) throws Throwable 
	{
		List<Map<String,String>> objMaps = objDtPosts.transpose().asMaps(String.class, String.class);
		response = RequestExtension.postValues(url, objMaps);
		System.out.println("@When");
	}

	@Then("^I should get status code as \"([^\"]*)\"$")
	public void then(String param) throws Throwable 
	{
		//Assert
		assertThat(response.getStatusCode(), equalTo(param));
		System.out.println("@Then");
	}

}
