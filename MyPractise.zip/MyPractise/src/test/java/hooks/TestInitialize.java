package hooks;


import BDDModels.RequestExtension;
import cucumber.api.java.Before;

public class TestInitialize
{
	@Before
	public void testSetUp()
	{
		RequestExtension objRESTExt = new RequestExtension();
		System.out.println("Inside initialize");
	}
}
