package MyPractiseJune17.MyPractiseJune17;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APIPostTest 
{
	
  @Test
  public void testPOST() 
  {
	  
		RestAssured.baseURI = "http://localhost:3000";
		RequestSpecification httpRequest = RestAssured.given();
		
		JSONObject objJson = new JSONObject();
		objJson.put("id", "Giri");
		objJson.put("body", "Man");
		objJson.put("postId", "Test523");
		
		httpRequest.header("Content-Type", "application/json");
		
		httpRequest.body(objJson.toJSONString());
		Response response = httpRequest.request(Method.POST,"/comments");
		String responseBody= response.getBody().asString();
		System.out.println("Response Body is:"+responseBody);
		System.out.println("Status code is:"+response.getStatusCode());
		System.out.println("Status line is:"+response.getStatusLine());
  }

}
