package MyPractiseJune17.MyPractiseJune17;

public class InterfaceTest implements Basic {
	
	public void state()
	{
		System.out.println("inside implemented class");
	}
	
	public void state1()
	{
		System.out.println("inside implemented class1");
	}

}
