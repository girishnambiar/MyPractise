package MyPractiseJune17.MyPractiseJune17;

import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest {
  
  @Test
  public void f() {
	  Assert.assertEquals(true, true,"tested successfully");
  }

}
