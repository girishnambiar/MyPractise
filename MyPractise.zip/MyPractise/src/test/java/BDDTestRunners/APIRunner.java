	package BDDTestRunners;

	import cucumber.api.CucumberOptions;
	import cucumber.api.testng.AbstractTestNGCucumberTests;

	//@RunWith(Cucumber.class)
	@CucumberOptions(strict=true,features = {"classpath:features"},
			glue = {"steps","hooks"},
			format = {"pretty", "html:target/Destination"},
			tags = {"@Test1","@scenario1", "~@ignore"},
			dryRun = false)
					
	public class APIRunner extends AbstractTestNGCucumberTests
	{ }
