	package BDDTestRunners;

	import cucumber.api.CucumberOptions;
	import cucumber.api.testng.AbstractTestNGCucumberTests;

	//@RunWith(Cucumber.class)
	@CucumberOptions(strict=true,features = {"classpath:features"},
			glue = {"steps","hooks"},
			format = {"pretty", "html:target/Destination"},
			tags = {"@Test2","@Scenario1"},
			dryRun = false)
					
	public class APIRunner2 extends AbstractTestNGCucumberTests
	{ }
