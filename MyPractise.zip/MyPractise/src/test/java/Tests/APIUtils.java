package Tests;

import java.io.FileInputStream;
import java.security.KeyStore;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class APIUtils 
{

	public void connectToAPI(String certPath, char[] password)
	{
		KeyStore keyStore = null;
		SSLConfig config = null;

		try {
			keyStore = KeyStore.getInstance("PKCS12");
			keyStore.load(
			      new FileInputStream(certPath),password);

		} catch (Exception ex) {
			System.out.println("Error while loading keystore >>>>>>>>>");
			ex.printStackTrace();
		}

		if (keyStore != null) {

			//org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);

			// set the config in rest assured
		//	config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

			RestAssured.config = RestAssured.config().sslConfig(config);
			RestAssured.given().when().get("/path").then();
		}

	}
	
	public void performAPICall(String strBaseURL, String strMethod, String param)
	{
		given()
			.baseUri(strBaseURL)
			.contentType(ContentType.JSON)
		.when()
			.get(strMethod)
		.then()
			.statusCode(201);
			//.body(param, equalTo("1"));
	}

}
