package Tests;

import org.junit.Test;
import static org.junit.Assert.*;
import org.testng.Assert;

import com.jayway.restassured.path.xml.XmlPath;

import static io.restassured.RestAssured.*;

import java.util.HashMap;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetData 
{
	/*@Test
	public void testResponseCode()
	{
		//RestAssured objRESTAssured = new RestAssured();
		//objRESTAssured.
		
		Response resp = get("https://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=439d4b804bc8187953eb36d2a8c26a02");
		int status = resp.getStatusCode();
		Assert.assertEquals(status, 200, "Passed");
		
	}
	
	@Test
	public void testBody()
	{
		//RestAssured objRESTAssured = new RestAssured();
		//objRESTAssured.
		HashMap objHash = new HashMap();
		objHash.put("id", "11");
		objHash.put("body", "hellow2orld");
		objHash.put("postId", "Test423");
		//Response resp = get("http://localhost:3000/comments");
		Response resp = post("http://localhost:3000/comments",objHash);
		String status = resp.asString();
		
		System.out.println(status);
		
		//Assert.assertEquals(status, 200, "Passed");
		
		
	}
	
	@Test
	public void testIndividually()
	{
		HashMap objHash = new HashMap();
		objHash.put("id", "14");
		objHash.put("body", "h243344");
		objHash.put("postId", "Test2234142");
		Response res = 
			given()
				.contentType("application/json")
				.body(objHash)
			.when()
				.post("http://localhost:3000/comments")
			.then()
				.statusCode(201)
				.log().body()
				.extract().response();
		String status = res.asString();
		
		System.out.println(status);
	}
	
	@Test
	public void testSwagger()
	{
		//HashMap objHash = new HashMap();
		//objHash.put("id", "14");
		//objHash.put("body", "h243344");
		//objHash.put("postId", "Test2234142");
		Response res = 
			given()
				.contentType("application/json")
				//.body(objHash)
			.when()
				.get("https://petstore.swagger.io/v2/pet/findByStatus?status=available")
			.then()
				.statusCode(201)
				.log().body()
				.extract().response();
		String status = res.asString();
		
		System.out.println(status);
	}*/
	
	@Test
	public void testXMLResponse()
	{
		//HashMap objHash = new HashMap();
		//objHash.put("id", "14");
		//objHash.put("body", "h243344");
		//objHash.put("postId", "Test2234142");
			String s = 
			given()
				.accept(ContentType.XML)
				//.body(objHash)
			.when()
				.get("http://parabank.parasoft.com/parabank/services/bank/customers/12212")
			.thenReturn()
				.asString();
			
			XmlPath objXml = new XmlPath(s);
			String strAddr = objXml.getString("customer.address.street");
			System.out.println(strAddr);
	
	}

}
