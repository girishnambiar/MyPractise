package Tests;

import org.testng.annotations.Test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class IndeedTest 
{
	WebDriver objDriv;

	@Test
	public void f() 
	{
		//List<WebElement> objWEs = objDriv.findElements(By.className("jobsearch-SerpJobCard unifiedRow row result clickcard"));
		List<WebElement> objWEs = objDriv.findElements(By.tagName("h2"));
		for(WebElement objWE: objWEs)
		{
			try
			{
				//WebElement objH2 = objDriv.findElement(By.tagName("h2"));
				if(objWE.getText().toLowerCase().contains("qa automation engineer")
							||objWE.getText().toLowerCase().contains("qa automation")
							|| objWE.getText().toLowerCase().contains("automation qa")
							|| objWE.getText().toLowerCase().contains("qa engineer")
							|| objWE.getText().toLowerCase().contains("quality assurance engineer")
							|| objWE.getText().toLowerCase().contains("(qa) engineer"))
				{
					objWE.click();
					if(objDriv.findElement(By.xpath("//*[@id='vjs-content']")).getText().matches("java|JAVA|Java|Selenium|selenium|SELENIUM"))
					{
						WebElement objContinue1 = objDriv.findElement(By.xpath("//*[@id='indeed-ia-1593305259622-0']"));
						objContinue1.click();
						Thread.sleep(3000);
						WebElement objContinue2 = objDriv.findElement(By.xpath("//*[@id='form-action-continue']"));
						objContinue2.click();
						Thread.sleep(3000);
						WebElement objContinue3 = objDriv.findElement(By.xpath("//*[@id='form-action-continue']"));
						objContinue3.click();
						Thread.sleep(3000);
						////*[@id="vjs-desc"]
						if(objDriv.findElement(By.xpath("//*[@id='q_4']/fieldset/div/legend")).getText().contains("employment eligibility"))
						{
							objDriv.findElement(By.xpath("//*[@id='label-radio-option-5']")).click();
						}
						if(objDriv.findElement(By.xpath("//*[@id='label-input-q_3457578568629d4fbab2983331b90f4']/label/span"))!=null &&
								objDriv.findElement(By.xpath("//*[@id='label-input-q_3457578568629d4fbab2983331b90f4']/label/span")).isDisplayed() &&
								objDriv.findElement(By.xpath("//*[@id='label-input-q_3457578568629d4fbab2983331b90f4']/label/span")).getText().contains("salary"))
						{
							if(objDriv.findElement(By.xpath("//*[@id='input-q_3457578568629d4fbab2983331b90f48']"))!=null &&
									objDriv.findElement(By.xpath("//*[@id='input-q_3457578568629d4fbab2983331b90f48']")).isDisplayed())
								objDriv.findElement(By.xpath("//*[@id='input-q_3457578568629d4fbab2983331b90f48']")).sendKeys("110000");
							WebElement objContinue4 = objDriv.findElement(By.xpath("//*[@id='form-action-continue']"));
							objContinue4.click();
							Thread.sleep(3000);
							if(objDriv.findElement(By.xpath("//*[@id='label-radio-option-8']"))!=null &&
									objDriv.findElement(By.xpath("//*[@id='label-radio-option-8']")).isDisplayed() &&
									objDriv.findElement(By.xpath("//*[@id='label-radio-option-8']")).getText().contains("Male"))
							{
								objDriv.findElement(By.xpath("//*[@id='label-radio-option-8']")).click();
							}
							objDriv.findElement(By.xpath("//*[@id='label-radio-option-12']")).click();
							if(objDriv.findElement(By.xpath("//*[@id='label-radio-option-12']"))!=null &&
									objDriv.findElement(By.xpath("//*[@id='label-radio-option-12']")).isDisplayed() &&
									objDriv.findElement(By.xpath("//*[@id='label-radio-option-12']")).getText().contains("I AM NOT A PROTECTED VETERAN"))
							{
								objDriv.findElement(By.xpath("//*[@id='label-radio-option-12']")).click();
							}
							objDriv.findElement(By.xpath("//*[@id='select-9']/option[6]")).click();
							if(objDriv.findElement(By.xpath("//*[@id='select-9']/option[6]"))!=null &&
									objDriv.findElement(By.xpath("//*[@id='select-9']/option[6]")).isDisplayed() &&
									objDriv.findElement(By.xpath("//*[@id='select-9']/option[6]")).getText().contains("Asian"))
							{
								objDriv.findElement(By.xpath("//*[@id='select-9']/option[6]")).click();
							}
							WebElement objContinue5 = objDriv.findElement(By.xpath("//*[@id='form-action-continue']"));
							if(objContinue5!=null && objContinue5.isDisplayed())
							{
								objContinue5.click();
							}
							if(objDriv.findElement(By.xpath("//*[@id='label-radio-option-15']"))!=null &&
									objDriv.findElement(By.xpath("//*[@id='label-radio-option-15']")).isDisplayed() &&
									objDriv.findElement(By.xpath("//*[@id='label-radio-option-15']")).getText().contains("NO, I DON'T HAVE A DISABILITY"))
							{
								objDriv.findElement(By.xpath("//*[@id='label-radio-option-15']")).click();
							}
							if(objDriv.findElement(By.xpath("//*[@id='input-q_5101ed923dd80929d6d6efcbeb8bc146']"))!=null &&
									objDriv.findElement(By.xpath("//*[@id='input-q_5101ed923dd80929d6d6efcbeb8bc146']")).isDisplayed())
							{
								objDriv.findElement(By.xpath("//*[@id='input-q_5101ed923dd80929d6d6efcbeb8bc146']")).sendKeys("Girish Gopinathan Nambiar");
							}
							if(objDriv.findElement(By.xpath("//*[@id='input-q_8920a21266ffe4273777162480b5636a']"))!=null &&
									objDriv.findElement(By.xpath("//*[@id='input-q_8920a21266ffe4273777162480b5636a']")).isDisplayed())
							{
								objDriv.findElement(By.xpath("//*[@id='input-q_8920a21266ffe4273777162480b5636a']")).sendKeys("2020-06-27");
							}
							WebElement objContinue6 = objDriv.findElement(By.xpath("//*[@id='form-action-continue']"));
							if(objContinue6!=null && objContinue6.isDisplayed())
							{
								objContinue6.click();
							}
							
							if(objDriv.findElement(By.xpath("//*[@id='form-action-submit']"))!=null &&
									objDriv.findElement(By.xpath("//*[@id='form-action-submit']")).isDisplayed())
							{
								objDriv.findElement(By.xpath("//*[@id='form-action-submit']")).click();
							}
						}
					}
				}
				if(objDriv.findElement(By.xpath("//*[@id='resultsCol']/nav/div/ul/li[7]/a/span/span/svg"))!=null &&
						objDriv.findElement(By.xpath("//*[@id='resultsCol']/nav/div/ul/li[7]/a/span/span/svg")).isDisplayed() &&
						objDriv.findElement(By.xpath("//*[@id='resultsCol']/nav/div/ul/li[7]/a/span/span/svg")).getText().contains(">"))
				{
					objDriv.findElement(By.xpath("//*[@id='resultsCol']/nav/div/ul/li[7]/a/span/span/svg")).click();
				}
				
			}
			catch(Exception objEx)
			{
				objEx.printStackTrace();
				System.out.println(objEx.getMessage());
			}
		}
	}
	@BeforeClass
	public void beforeClass() throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "E:\\Apps\\chromedriver_win32\\chromedriver.exe");
		objDriv = new ChromeDriver();
		objDriv.get("https://ca.indeed.com/?from=gnav-homepage");
		Thread.sleep(3000);
		if(objDriv.findElement(By.xpath("//*[@id='text-input-what']"))!=null &&
				objDriv.findElement(By.xpath("//*[@id='text-input-what']")).isDisplayed())
			objDriv.findElement(By.xpath("//*[@id='text-input-what']")).sendKeys("qa automation engineer");
		if(objDriv.findElement(By.xpath("//*[@id='text-input-where']"))!=null &&
				objDriv.findElement(By.xpath("//*[@id='text-input-where']")).isDisplayed())
			objDriv.findElement(By.xpath("//*[@id='text-input-where']")).sendKeys("Toronto, ON");
		if(objDriv.findElement(By.xpath("//*[@id='text-input-where']"))!=null &&
				objDriv.findElement(By.xpath("//*[@id='whatWhereFormId']/div[3]/button")).isDisplayed())
			objDriv.findElement(By.xpath("//*[@id='whatWhereFormId']/div[3]/button")).click();
		Thread.sleep(3000);
	}
}