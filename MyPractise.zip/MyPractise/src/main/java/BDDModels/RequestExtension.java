package BDDModels;

import io.restassured.response.Response;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.restassured.RestAssured;
import io.restassured.builder.*;
import io.restassured.http.ContentType;
import io.restassured.specification.*;

public class RequestExtension 
{
	public static RequestSpecification request;
	
	public RequestExtension()
	{
		//Arrange
		RequestSpecBuilder objSpec = new RequestSpecBuilder();
		objSpec.setBaseUri("http:////localhost:3000//posts");
		objSpec.setContentType(ContentType.JSON);
		RequestSpecification objReqSpec = objSpec.build();
		request = RestAssured.given().spec(objReqSpec);
	}
	
	public static Response getOPS(String url) throws Exception
	{
		//Act
		Response objRes = request.get();
		return objRes;
	}
	
	public static Response postValues(String url, List<Map<String, String>> objMaps) throws Exception
	{
		//Act
		Iterator<?> iter = objMaps.iterator();
		while(iter.hasNext())
		{
			Map<String,String> objMap = (Map<String,String>)iter.next();
			request.body(objMap);
			request.post(new URL("http:////localhost:3000//posts"));
		}
		
		Response objRes = request.get();
		return objRes;
	}

}
