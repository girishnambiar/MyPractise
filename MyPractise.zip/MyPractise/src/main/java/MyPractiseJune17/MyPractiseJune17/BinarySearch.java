package MyPractiseJune17.MyPractiseJune17;

public class BinarySearch {

	public static void main(String[] args) 
	{
		int[] intArray = {1,9,23,34,45,55,56,67,89};
		//int search = 45;
		
		for(int i=2;i<(intArray.length/2);i+=2)
		{
			
		}
	}
}
