package MyPractiseJune17.MyPractiseJune17;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.util.Iterator;

public class JSONParser_Exercise1 
{
	public static void main(String[] args) throws FileNotFoundException, ParseException, IOException
	{
		File objFile = new File("C:\\Users\\Girish\\Desktop\\files\\response.json");
		FileReader objFIP = new FileReader(objFile);
		JSONParser objParser = new JSONParser();
		JSONObject objJSON = (JSONObject)(objParser.parse(objFIP));
		Iterator<?> objIter = objJSON.keySet().iterator();
		if(objJSON.containsKey("id"))
		{
			System.out.println(objJSON.get("id"));
		}
		while(objIter.hasNext())
		{
			String objKey = (String)objIter.next();
			if(objJSON.get(objKey) instanceof JSONObject)
			{
				if(((JSONObject) objJSON.get(objKey)).containsKey("id"))
				{
					System.out.println(((JSONObject)objJSON.get(objKey)).get("id"));
				}
				
			}
			else if(objJSON.get(objKey) instanceof JSONArray)
			{
				Iterator<?> arrayIterator = ((JSONArray) objJSON.get(objKey)).iterator();
				while(arrayIterator.hasNext())
				{
					Object objJO = arrayIterator.next();
					if(((JSONObject)objJO).containsKey("id"))
					{
						System.out.println(((JSONObject)objJO).get("id"));
					}
				}
			}
		}
	}
}
