package MyPractiseJune17.MyPractiseJune17;

import java.util.Scanner;

public class Fibanacci 
{

	public static void main(String[] args) 
	{
	     /* This reads the input provided by user
         * using keyboard
         */
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter any number: ");

        // This method reads the number provided using keyboard
        int num = scan.nextInt();
   
    	System.out.print("The fibanacci series is: ");
    	int a = 0;
    	int b = 1;
    	int c = 0;
        for(int i=1;i<=num;i++)
        {
        	c = a + b;
        	System.out.print(a+" ");
        	a = b;
        	b = c;
        }
        
        fibanacci(num);

        scan.close();
	}
	
	public static void fibanacci(int limit)
	{
		int a = 0, b = 1, c = 2;
		System.out.println("");
		System.out.print("The fibanacci series is: ");
		while(a<=limit)
		{
			c = a + b;
			System.out.print(a+" ");
			a = b;
			b = c;
		}
	}

}
