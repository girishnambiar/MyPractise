package MyPractiseJune17.MyPractiseJune17;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Solution {

    // Complete the hourglassSum function below.
    static int hourglassSum(int[][] arr) 
    {
        int sum = 0;
        ArrayList<Integer> objSList = new ArrayList();
        for(int i=0; i<=arr.length; i++)
        {
            int k = 0;
            sum = 0;
            objSList.add(sum);
            for(int j=0; j<=arr.length; j++)
            {
                k = j;
                sum = 0;
                System.out.println(arr[i].length);
                System.out.println(arr.length);
                if(k+2<=arr[i].length && i+2<=arr.length) //row addition
                {
                    sum = sum + arr[i][k];
                    sum = sum + arr[i][k+1];
                    sum = sum + arr[i][k+2];
                    sum = sum + arr[i+1][k+1];
                    sum = sum + arr[i+2][k];
                    sum = sum + arr[i+2][k+1];
                    sum = sum + arr[i+2][k+2];
                    if(objSList.get(objSList.size()-1) < sum)
                        objSList.add(sum);
                }
            }
        }
        return objSList.get(objSList.size()-1);
    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int[][] arr = new int[6][6];

        for (int i = 0; i < 6; i++) {
            String[] arrRowItems = scanner.nextLine().split(" ");
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

            for (int j = 0; j < 6; j++) {
                int arrItem = Integer.parseInt(arrRowItems[j]);
                arr[i][j] = arrItem;
            }
        }

        int result = hourglassSum(arr);

        bufferedWriter.write(String.valueOf(result));
        bufferedWriter.newLine();

        bufferedWriter.close();

        scanner.close();
    }
}

