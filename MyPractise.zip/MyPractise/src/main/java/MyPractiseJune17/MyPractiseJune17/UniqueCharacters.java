package MyPractiseJune17.MyPractiseJune17;

import java.util.Scanner;

public class UniqueCharacters 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter any string: ");

		// This method reads the number provided using keyboard
		String input = scan.next();
		boolean boolFlag = false;
		char chrI = ' ';
		for(int i=0; i<input.length(); i++)
		{
			chrI = input.charAt(i);
			int counter = 0;
			for(int j=0; j<input.length(); j++)
			{
				char chrJ = input.charAt(j);
				if(chrI==chrJ)
				{
					counter++;
				}
			}
			if(counter>1)
			{
				boolFlag = true;
				break;
			}
		}
		if(!boolFlag)
		{
			System.out.print("All characters in the given string is unique !!!!");
		}
		else
		{
			System.out.print("All characters in the given string is NOT unique !!!!");
		}
	}
}
