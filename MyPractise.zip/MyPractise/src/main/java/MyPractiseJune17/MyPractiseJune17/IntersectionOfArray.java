package MyPractiseJune17.MyPractiseJune17;

import java.util.ArrayList;
import java.util.Scanner;

public class IntersectionOfArray { 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner objScan = new Scanner(System.in);
		System.out.print("Enter no.of elements of first array: ");
		int intN1 = objScan.nextInt();
		System.out.print("Enter no.of elements of second array: ");
		int intN2 = objScan.nextInt();

		int[] intArray1 = new int[intN1];
		int[] intArray2 = new int[intN2];
		ArrayList<Integer> objInterSectionList = new ArrayList<Integer>();
		
		System.out.print("Enter elements of first array: ");
		for(int i=0; i<intN1; i++)
		{
			intArray1[i] = objScan.nextInt();
		}

		System.out.print("Enter elements of second array: ");
		for(int j=0; j<intN2; j++)
		{
			intArray2[j] = objScan.nextInt();
		}

		for(int i=0; i<intN1; i++)
		{
			int intElement1 = intArray1[i];
			for(int j=0; j<intN2; j++)
			{
				if(intElement1==intArray2[j])
				{
					objInterSectionList.add(intElement1);
				}
			}
		}

		System.out.print("The intersection of arrays is: "+objInterSectionList.toString());

	}

}
