package MyPractiseJune17.MyPractiseJune17.serialization;

import com.google.gson.Gson;

public class Serialse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PayLoad[] objPay = {new PayLoad("1","jsonserver","typecode"),
				new PayLoad("2","jsonserver2","typecode2"),
				new PayLoad("3","jsonserver3","typecode3")};
		posts objPost = new posts(objPay);
		field objField = new field(objPost);
		Gson objG = new Gson();
		String strJson = objG.toJson(objField);
		System.out.println(strJson);
	}

}

class field
{
	private posts Posts;
	field(posts objPost)
	{
		this.Posts = objPost;
	}
	public posts getObjPost() {
		return Posts;
	}
	public void setObjPost(posts objPost) {
		this.Posts = objPost;
	}
	
}

class posts
{
	private PayLoad[] PayLoad;
	
	posts(PayLoad[] objPayLoad)
	{
		this.PayLoad = objPayLoad;
	}

	public PayLoad[] getObjPayLoad() {
		return PayLoad;
	}

	public void setObjPayLoad(PayLoad[] objPayLoad) {
		this.PayLoad = objPayLoad;
	}
	
}

class PayLoad
{
	private String id;
	private String title;
	private String author;
	
	PayLoad(String id, String title, String author)
	{
		this.id = id;
		this.title = title;
		this.author = author;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
}
