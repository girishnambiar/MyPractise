package MyPractiseJune17.MyPractiseJune17;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.*;

public class Excelhandling 
{

	public static void main(String[] args) throws IOException 
	{
		
		String[] strValues = {"Hello","World"};
		
		putCellValues(strValues);
		getCellValues();

	}
	
	public static void getCellValues() throws IOException 
	{
		File objFile = new File("E:\\AOL\\TTC\\TTC requirements.xlsx");
		
		FileInputStream fio = new FileInputStream(objFile);
		
		XSSFWorkbook objBook = new XSSFWorkbook(fio);
		XSSFSheet objSheet = objBook.getSheet("June21");
		
		int intRows = objSheet.getLastRowNum();
		int intCols = objSheet.getRow(0).getLastCellNum();
		
		for(int intRowIter=0; intRowIter<=intRows; intRowIter++)
		{
			for(int intColIter=0; intColIter<=intCols; intColIter++)
			{
				XSSFCell objCell = objSheet.getRow(intRowIter).getCell(intColIter);
				if(objCell!=null)
				{
					try
					{
						System.out.print(objCell.getStringCellValue() + " ");
					}
					catch(java.lang.IllegalStateException objEx){
						System.out.print(objCell.getNumericCellValue() + " ");
					}
				}
			}
			System.out.println("");
		}
		
		fio.close();
	}
	
	public static void putCellValues(String[] strValues) throws IOException 
	{
		File objFile = new File("E:\\AOL\\TTC\\TTC requirements.xlsx");

		FileInputStream fio = new FileInputStream(objFile);

		XSSFWorkbook objBook = new XSSFWorkbook(fio);
		XSSFSheet objSheet;
		int intRow = 0;
		if(objBook.getSheet("June21")==null)
		{
			objSheet = objBook.createSheet("June21");
		}
		else
		{
			objSheet = objBook.getSheet("June21");
			intRow = objSheet.getLastRowNum();
		}
		
		XSSFRow objRow = objSheet.createRow(intRow);

		for(int intColIter=0; intColIter<strValues.length; intColIter++) 
		{
			XSSFCell objCell = objRow.createCell(intColIter);
			if(objCell!=null)
			{
				try
				{
					objCell.setCellValue(strValues[intColIter]);
				}
				catch(java.lang.IllegalStateException objEx){
					objCell.setCellValue(strValues[intColIter]);
				}
			}
		}

		FileOutputStream fout = new FileOutputStream(objFile);
		objBook.write(fout);

		fio.close();

		fout.close();
	}

}
