function StopWatch () 
{
		
	let intStartTime, intEndTime, running, intDuration=0;
		
	this.start() = function()
	{
		if(running)
		{
			throw error("Stop watch is already running");
		}
		running = true;
		intStartTime = new Date();
	};
		
	this.stop() = function()
	{
		intEndTime = new Date();
		intDuration += (intEndTime.getTime()/1000) - (intStartTime.getTime()/1000);
		
	};
	
	this.reset() = function()
	{
		intStartTime = null;
		intEndTime = null;
		running = false;
		intDuration = 0;
	};
	
	Object.defineProperty(this, 'duration', {get: function() { return duration; }});
		
}