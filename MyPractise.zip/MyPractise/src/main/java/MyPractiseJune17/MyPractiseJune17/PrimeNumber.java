package MyPractiseJune17.MyPractiseJune17;

import java.util.Scanner;

public class PrimeNumber 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter any integer greater than 0 :");
		int number = scan.nextInt();
		if(number>1)
		{
			int dividerlimit = number/2;
			int n = 2;
			boolean boolFlag = false;
			while(n<=dividerlimit)
			{
				if(number%n==0)
				{
					boolFlag = true;
					break;
				}
				
				n = n + 1;
			}
			if(boolFlag)
			{
				System.out.println("'" + number + "' is not a prime number");
			}
			else
			{
				System.out.println("Yes!! '" + number + "' is a prime number !!");
			}
		}
		else
		{
			System.out.println("'" + number + "' is not a prime number");
		}
		
		scan.close();
	}
}
