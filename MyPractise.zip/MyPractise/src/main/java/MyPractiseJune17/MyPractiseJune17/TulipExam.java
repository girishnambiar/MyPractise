package MyPractiseJune17.MyPractiseJune17;

public class TulipExam {

	public static void main(String[] args) 
	{
		
		
		

	}

}
