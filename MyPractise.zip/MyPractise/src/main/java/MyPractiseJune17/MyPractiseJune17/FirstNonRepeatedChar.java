package MyPractiseJune17.MyPractiseJune17;

import java.util.Scanner;

public class FirstNonRepeatedChar {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter any string: ");

		// This method reads the number provided using keyboard
		String input = scan.next();
		boolean boolFlag = false;
		char chrI = ' ';
		for(int i=0; i<input.length(); i++)
		{
			chrI = input.charAt(i);
			int counter = 0;
			for(int j=0; j<input.length(); j++)
			{
				char chrJ = input.charAt(j);
				if(chrI==chrJ)
				{
					counter++;
				}
			}
		}
		System.out.print("First non repeated char in the input string " + input + " is: "+chrI);
	}
}
