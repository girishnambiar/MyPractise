package MyPractiseJune17.MyPractiseJune17;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.util.HashMap;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.JsonElement;
import io.cucumber.messages.internal.com.google.gson.JsonObject;

public class JSONFileWriting 
{

	public static void main(String[] args) throws Exception
	{

		/*HashMap<String, String> objHash = new HashMap<String, String>();
		objHash.put("Name","Nambiar");
		objHash.put("Phone","8609957700");
		objHash.put("Email","girishN1.nambiar@gmail.com");
		HashMap<String, String> objHash1 = new HashMap<String, String>();
		objHash1.put("Name","John");
		objHash1.put("Phone","8611957700");
		objHash1.put("Email","Prime.J1@gmail.com");
		HashMap<String, String> objHash2 = new HashMap<String, String>();
		objHash2.put("Name","Jacob");
		objHash2.put("Phone","8609957722");
		objHash2.put("Email","Jack@gmail.com");
		HashMap<String, HashMap<String, String>> objPHash = new HashMap<String, HashMap<String, String>>();
		objPHash.put("member1", objHash);
		objPHash.put("member2", objHash1);
		objPHash.put("member3", objHash2);
		
		FileWriter objFW = new FileWriter(new File("c:\\Users\\Girish\\Desktop\\Me.sjon"));
		objFW.write(objPHash.toString());
		objFW.close();*/
		
		String objStr = "";
		
		//FileReader objFR = new FileReader(new File("c:\\Users\\Girish\\Desktop\\Me.sjon"));//new FileInputStream(new File("c:\\Users\\Girish\\Desktop\\Me.sjon"))
		//JsonObject objJS = new JsonObject();
		//System.out.println(objJS.get("Name"));
		
		JSONParser objParse = new JSONParser();
		JSONArray objArray = (JSONArray)objParse.parse(new FileReader("c:\\Users\\Girish\\Desktop\\comments.json"));
		//JSONArray objArray = (JSONArray)objParsed.get(0);
		//System.out.println(objParsed);
		Iterator<?> objIter = objArray.iterator();
		while(objIter.hasNext())
		{
			JSONObject objMem = (JSONObject) objIter.next();
			System.out.println(objMem.get("body"));
			System.out.println(objMem.toString());
		}
		
		//JSONArray objJArr = (JSONArray)objParsed.get("Name");
		
	//	Iterator<JSONObject> iter = objJArr.iterator();
		//while(iter.hasNext())
		//{
		//	System.out.println(iter.next());
		//}
	
	}

}
